package com.xloop.resourceloop.candidateprofile.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface ICandidatePersonalityTestRepository {
    
}
