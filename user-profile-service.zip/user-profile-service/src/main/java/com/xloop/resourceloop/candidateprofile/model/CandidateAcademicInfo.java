package com.xloop.resourceloop.candidateprofile.model;

public class CandidateAcademicInfo {
    
}
