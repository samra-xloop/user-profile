package com.xloop.resourceloop.candidateprofile.controller;

public class CandidateAcademicInfoController {
    
}
