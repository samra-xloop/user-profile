package com.xloop.resourceloop.candidateprofile;

public class Gender {

}
