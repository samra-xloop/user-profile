# user-profile-service
This repo is for the user-profile microservice for the ResourceLoop project.
